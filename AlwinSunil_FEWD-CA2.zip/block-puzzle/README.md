# Block Puzzle

## Project for Frontend development CA 2

This project is a clone of an andriod game, [Block Puzzle](https://play.google.com/store/apps/details?id=com.dxm.nopuzzle&pcampaignid=web_share) by Candy Mobile available from PlayStore.
